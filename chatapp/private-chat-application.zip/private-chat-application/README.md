# Private Chat Application
Private Chat Application with Node.js, Socket.IO and AngularJS
